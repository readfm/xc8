https://youtu.be/kZiKYmK9Usw?t=18

TAG eat tabs

tabs if too many, then list text tabs under TAG, sort list

indexed_db saves local, could sync to F:/drive and server.tld/~usr/tag 

time unix timestamp stream for 1 user in 1 memory, then copy maybe

# ab8 program   
1 OFF/on switch    
2 TEXT input     
3 LINK: text; time; url; etc     
4 LIST text links      
5 TAG /maybe /not             
6 AB /select /option     
7 C new option(s)   
8 THING /old /new /want      

programmable meme thing, find, bet, <more less>

![8play](https://user-images.githubusercontent.com/2864627/130834499-d041b44e-d9d9-4abf-8e61-6f4b4ec8db4f.gif)
